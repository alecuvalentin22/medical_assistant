var hndProd = null;

window.onload = function () {

    console.log ('window has loaded');

    var hndCat = document.getElementById('cat_list');
    hndProd = document.getElementById('prod_list');

    for (i=0; i<p.categories.length; i++) {
        console.log (p.categories[i].name);

        let dobj = document.createElement('div');
        let tobj = document.createTextNode(p.categories[i].name)
        dobj.classList.add('col-2');
        dobj.classList.add('category');
        dobj.setAttribute('id', 'categorie-' + p.categories[i].id);
        dobj.appendChild(tobj);    
        hndCat.appendChild(dobj);
    }


    var cls = document.getElementsByClassName('category');
    for (i=0; i<cls.length; i++) {
        cls[i].addEventListener('click', changeCategory, false);

    }
};

function changeCategory (elem) {
    let cat_id = this.getAttribute('id').replace('categorie-', '');
    
    console.log(cat_id);
    let prods = p.produse.filter(elem => elem.catId == cat_id);
    
    hndProd.innerHTML = '';
    
    prods.forEach(elem => {
        let dobj = document.createElement('div');
        let tobj = document.createTextNode(elem.name)

        dobj.classList.add('col-2');
        dobj.classList.add('product');
        dobj.setAttribute('id', 'product-' + elem.id);
        dobj.appendChild(tobj);    

        if (elem.img !== undefined) {
            let imgObj = document.createElement('img');
            imgObj.setAttribute('src', '../poze/' + elem.img);
            imgObj.classList.add('img-produs');
            dobj.appendChild(imgObj);
        }
        
        hndProd.appendChild(dobj);    
    });
    
}
