navigator.geolocation.getCurrentPosition(function(position) {
    console.log(position.coords.latitude + ' ' + position.coords.longitude);
    let l=document.getElementById("google_map");
    l.setAttribute("src", "https://www.google.com/maps/embed?pb" + position.coords.latitude + ',' + position.coords.longitude);


    let u = document.getElementById('user_pos');
    u.innerHTML = position.coords.latitude + ', ' + position.coords.longitude;

    
  });