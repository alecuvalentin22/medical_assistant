var p = {
    categories: [
        {
            id:1, name:'Cleansers'
        },

        {
            id:2,name:'Powder'
        }, 

        {
            id:3, name:'Brushes'
        }, 

        {
            id:4, 
            name: 'Lipstick'
        }
    ]

    ,produse: [
        {
            id:4, catId:3, name:'Noelle Brush', img: 'Noelle Brush.jpg', 
        },

        {
            id:7, catId:3, name:'Sonia Brush' , img: 'Sonia Brush.jpg'
        },

        {
            id:8, catId:3, name:"Noelle Eyebrow", img: 'Noelle Eyebrow.jpg'
        },

        {
            id:9, catId:3, name:"Setting Brush", img: 'Setting Brush.jpeg'
        },

        {
            id:5, catId:2, name:'Nyx powder', img: 'Pudra Nyx.jpg'
        },

        {
            id:6, catId:1, name:'Cleanser Cerave', img: 'Cleanser Cerave.jpg'
        },

        {
            id:10, catId:1, name:'Cleanser Cetaphil', img: 'Cleanser Cetaphil.jpg'
        },

        {
            id:11, catId:1, name:'Cleanser Johnson', img: 'Cleanser Johnson.jpg'
        },

        {
            id:12, catId:1, name:'Cleanser Laroche', img: 'Cleanser Laroche.jpg'
        },

        {
            id:13, catId:2, name:'Powder Cupio', img: 'Powder Cupio.jpg'
        },

        {
            id:14, catId:2, name:'Powder Milani', img: 'Powder Milani.jpg'
        },

        {
            id:15, catId:2, name:'Powder Sleek', img: 'Powder Sleek.jpeg'
        },

        {
            id:16, catId:4, name:'Mac Lipstick', img: 'Ruj Mac.jpg'
        },

        {
            id:17, catId:4, name:'Revers Lipstick', img: 'Revers Lipstick.jpg'
        },

        {
            id:18, catId:4, name:'Melkior Lipstick', img: 'Melkior Lipstick.jpg'
        },

        {
            id:19, catId:4, name:'Nyx Matte Lipstick', img: 'Nyx Matte Lipstick.jpg'
        },
    ]
}

